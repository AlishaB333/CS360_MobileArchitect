package com.example.ab_eventapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DatabaseHelper extends SQLiteOpenHelper{

     public static final String DATABASE_NAME = "User.db";
     public static final String TABLE_NAME = "user_table";
     public static final String COL_1 = "ID";
     public static final String COL_2 = "USERNAME";
     public static final String COL_3 = "PASSWORD";

     public static final String EVENT_TABLE = "event_table";
     public static final String EVENT_COL_1 = "ID";
     public static final String EVENT_COL_2 = "NAME";
     public static final String EVENT_COL_3 = "DATE";

     public DatabaseHelper(Context context){
          super(context, DATABASE_NAME, null, 1);
     }

     @Override
     public void onCreate(SQLiteDatabase db) {
          db.execSQL("CREATE TABLE " + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME TEXT, PASSWORD TEXT)");
          db.execSQL("CREATE TABLE " + EVENT_TABLE + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, DATE TEXT)");
     }

     @Override
     public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
          db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
          db.execSQL("DROP TABLE IF EXISTS " + EVENT_TABLE);
          onCreate(db);
     }

     //Insert a new user
     public boolean insertUser(String username, String password){
          SQLiteDatabase db = this.getWritableDatabase();
          ContentValues contentValues = new ContentValues();
          contentValues.put(COL_2, username);
          contentValues.put(COL_3, password);
          long result = db.insert(TABLE_NAME, null, contentValues);
          return result != -1; //If result is -1 then the insert has failed
     }

     //Check if user exists
     public boolean checkUser(String username, String password){
          SQLiteDatabase db = this.getReadableDatabase();
          Cursor cursor = db.rawQuery("SELECT  * FROM " + TABLE_NAME + " WHERE USERNAME=? AND PASSWORD=?", new String[]{username, password});
          return cursor.getCount() > 0;
     }

     //Insert new Event
     public boolean insertEvent(String name, String date){
          SQLiteDatabase db = this.getWritableDatabase();
          ContentValues contentValues = new ContentValues();
          contentValues.put(EVENT_COL_2, name);
          contentValues.put(EVENT_COL_3, date);
          long result = db.insert(EVENT_TABLE, null, contentValues);
          return result != -1; //If result is -1 then the insert has failed
     }

     //Get all Events
     public Cursor getAllEvents(){
          SQLiteDatabase db = this.getWritableDatabase();
          return db.rawQuery("SELECT * FROM " + EVENT_TABLE, null);
     }

     //Update Event
     public boolean updateEvent(String id, String name, String date){
          SQLiteDatabase db = this.getWritableDatabase();
          ContentValues contentValues = new ContentValues();
          contentValues.put(EVENT_COL_2, name);
          contentValues.put(EVENT_COL_3, date);
          db.update(EVENT_TABLE, contentValues, "ID = ?", new String[]{id});
          return true;
     }

     //Delete Event
     public Integer deleteEvent(String id){
          SQLiteDatabase db = this.getWritableDatabase();
          return db.delete(EVENT_TABLE,"ID = ?", new String[]{id});
     }

}
