package com.example.ab_eventapp;

import android.os.Bundle;
import android.content.Intent;
import android.database.Cursor;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    DatabaseHelper myDb;
    EditText username, password;
    Button loginbtn,registerbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        myDb = new DatabaseHelper(this);

        username = findViewById(R.id.editTextUsername);
        password = findViewById(R.id.editTextPassword);
        loginbtn  = findViewById(R.id.buttonLogin);
        registerbtn = findViewById(R.id.buttonRegister);

        login();
        register();
    }

    public void login() {
        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                boolean res = myDb.checkUser(user, pass);
                if (res) {
                    Toast.makeText(LoginActivity.this, "LOGIN APPROVED", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(LoginActivity.this, "LOGIN NOT APPROVED", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void register(){
        registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                String user = username.getText().toString();
                String pass = password.getText().toString();
                boolean isInserted = myDb.insertUser(user, pass);
                if(isInserted){
                    Toast.makeText(LoginActivity.this, "Registration Successful!", Toast.LENGTH_SHORT).show();
                } else{
                    Toast.makeText(LoginActivity.this, "Registration Failed =(", Toast.LENGTH_SHORT).show();
                }
            }

        });
    }
}
