package com.example.ab_eventapp;

import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

public class dbActivity extends AppCompatActivity {

    DatabaseHelper myDb;
    EditText editName, editDate, editID;
    Button btnAddData, btnViewAll, btnUpdate, btnDelete;
    GridView gridView;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDb = new DatabaseHelper(this);

        editName = findViewById(R.id.editTextName);
        editDate = findViewById(R.id.editTextDate);
        editID = findViewById(R.id.editTextId);
        btnAddData = findViewById(R.id.buttonAdd);
        btnViewAll = findViewById(R.id.buttonView);
        btnUpdate = findViewById(R.id.buttonUpdate);
        btnDelete = findViewById(R.id.buttonDelete);
        gridView = findViewById(R.id.gridView);

        addData();
        viewAll();
        updateData();
        deleteData();
    }

    public void addData(){
        btnAddData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isInserted = myDb.insertEvent(editName.getText().toString(), editDate.getText().toString());
                if (isInserted)
                    Toast.makeText(dbActivity.this, "Data Inserted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(dbActivity.this, "Data Insertion Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void viewAll(){
        btnViewAll.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Cursor res = myDb.getAllEvents();
                if (res.getCount()==0){
                    Toast.makeText(dbActivity.this, "No Data Found", Toast.LENGTH_SHORT).show();
                    return;
                }

                String[] fromFieldNames = new String[] {DatabaseHelper.EVENT_COL_2, DatabaseHelper.EVENT_COL_3};
                int[] toViewIDs = new int[]{android.R.id.text1, android.R.id.text2};
                SimpleCursorAdapter myCursorAdapter = new SimpleCursorAdapter(getBaseContext(), android.R.layout.simple_list_item_2, res, fromFieldNames, toViewIDs, 0);
                gridView.setAdapter(myCursorAdapter);
            }
        });
    }

    public void updateData(){
        btnUpdate.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                boolean isUpdated = myDb.updateEvent(editID.getText().toString(), editName.getText().toString(), editDate.getText().toString());
                if(isUpdated)
                    Toast.makeText(dbActivity.this, "Data Updated", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(dbActivity.this, "Data NOT Updated", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void deleteData(){
        btnDelete.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Integer deletedRows = myDb.deleteEvent(editID.getText().toString());
                if(deletedRows > 0)
                    Toast.makeText(dbActivity.this, "Data Deleted", Toast.LENGTH_SHORT).show();
                else Toast.makeText(dbActivity.this, "Data NOT Deleted", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
